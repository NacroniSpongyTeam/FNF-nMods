Hello. I am going to show you how to import the iconGrid mod I made for Friday Night Funkin' Version 0.2.6.



## Table of Contents
[Information](#information)
[How to import](#how-to-import)

## Information
The purpose of this mod is to change the icons to 0.2.4 or lower "when the icon update never existed".

## How to Import
The way to import this is to go to your Friday Night Funkin' Root folder, going to assets/images, and then move the original "iconGrid.png" file that isn't the "images" folder. Then copy and paste the iconGrid included in this ".zip" file into the "images" folder. Open "Funkin.exe", which is the game, to test out the icons.